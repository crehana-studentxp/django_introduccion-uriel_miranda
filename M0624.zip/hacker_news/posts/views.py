from django.shortcuts import render
from .models import Post
# Create your views here.
def home(request):
    return render(request, 'website/home.html',{
        "news": Post.objects.all()
    })

    