from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def welcome(request):
    return render(request,"website/welcome.html",{
        "info": "Curso introductorio Django",
        "suma": 5+2
    })

def home(request):
    return HttpResponse("Hacker News")