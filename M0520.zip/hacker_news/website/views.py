from django.shortcuts import render
from django.http import HttpResponse
from posts.models import Post
# Create your views here.
def welcome(request):
    return render(request,"website/welcome.html",{
        "info": "Curso introductorio Django",
        "suma": 5+2
    })

def home(request):
    return render(request, 'website/home.html',{
        "news": Post.objects.count()
    })